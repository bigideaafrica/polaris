#!/bin/bash
# Run the Polaris Installer from the directory where this script is located
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
$DIR/polaris-installer
