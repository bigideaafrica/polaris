#!/bin/bash
# Create a symlink to the executable in /usr/local/bin
ln -sf /usr/share/polaris-installer/polaris-installer /usr/local/bin/polaris-installer

# Update desktop database
if command -v update-desktop-database >/dev/null 2>&1; then
    update-desktop-database -q
fi

echo "Polaris Installer has been installed successfully."
echo "You can run it from your applications menu or by typing 'polaris-installer' in terminal."
